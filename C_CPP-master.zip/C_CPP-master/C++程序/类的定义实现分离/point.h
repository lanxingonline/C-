class point
{
public:
	void input(int, int);
	int getx();
	int gety();
private:
	int x;
	int y;
};

void show();