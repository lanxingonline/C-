#include "point.h"
// �Զ����ͷ�ļ�Ҫ�� " "

void point::input(int a, int b)
{
//	show();
	x = a;
	y = b;
}

int point::getx(void) 
{
	return x;
}

int point::gety(void)
{
	return y;
}

