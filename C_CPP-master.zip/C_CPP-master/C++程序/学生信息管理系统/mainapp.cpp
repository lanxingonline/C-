#include "student.h"

int main(void)
{
	ui face;

	face.display();
	face.wait();

	return 0;
}

